#include "types.h"
#include "stat.h"
#include "user.h"

#undef exit
#undef wait

#define N  1000

void
forktest(void)
{
  int n, pid;
  int status;

  printf(1, "exit/wait test\n");

  for(n=0; n<N; n++){
    pid = fork();
    if(pid < 0)
      break;

    if(pid == 0){
      if(n % 2 == 0){
        exit(n);        // hijo sale con código n
      } else {
        exit(0);        // otros hijos salen con 0
      }
    }
  }

  if(n == 0){
    printf(1, "no children\n");
    return;
  }

  for(; n > 0; n--){
    pid = wait(&status);
    if(pid < 0){
      printf(1, "wait() error\n");
      exit(-1);
    }
    printf(1, "pid %d exited with status %d\n", pid, status);
  }

  if(wait(0) != -1){
    printf(1, "wait got too many\n");
    exit(-1);
  }

  printf(1, "exit/wait test OK\n");
}

int
main(void)
{
  forktest();
  exit(0);
}

